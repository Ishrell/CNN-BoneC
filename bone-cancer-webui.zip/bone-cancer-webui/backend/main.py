import os
import io
import base64
from typing import List, Optional
from tensorflow.keras.models import model_from_json



import numpy as np
from PIL import Image

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Try to import TensorFlow/Keras lazily so the server can start even if not installed yet
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
try:
    import tensorflow as tf
    from tensorflow.keras.models import load_model
    from tensorflow.keras import backend as K
    TF_AVAILABLE = True
except Exception as e:
    TF_AVAILABLE = False
    tf = None
    load_model = None
    K = None

APP_TITLE = "Bone Cancer Scan API"
DEFAULT_IMG_SIZE = int(os.getenv("IMG_SIZE", "224"))
MODEL_PATH = os.getenv("MODEL_PATH", "model.h5")
MODEL_LOAD_MODE = os.getenv("MODEL_LOAD_MODE", "auto")  # auto|h5|savedmodel|json_weights
MODEL_JSON_PATH = os.getenv("MODEL_JSON_PATH", "model_arch.json")
MODEL_WEIGHTS_PATH = os.getenv("MODEL_WEIGHTS_PATH", "model_CNN_BC.weights.h5")
CLASS_NAMES_ENV = os.getenv("CLASS_NAMES", "Normal,Abnormal")
CLASS_NAMES: List[str] = [c.strip() for c in CLASS_NAMES_ENV.split(",") if c.strip()]

USE_GRADCAM = os.getenv("USE_GRADCAM", "1") == "1"
LAST_CONV_FALLBACK = os.getenv("LAST_CONV_LAYER", "")  # optional: set last conv layer name

app = FastAPI(title=APP_TITLE, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

model = None

# ======== PREPROCESSING CONFIG (set these to your Kaggle notebook values) ========
PREP = {
    "to_grayscale": True,          # True if you trained on grayscale X-rays
    "center_square_crop": True,    # True if you cropped to square before resize
    "target_size": DEFAULT_IMG_SIZE,  # keep as is or set your exact input size
    "use_clahe": False,            # True if you used CLAHE (histogram equalization)
    "clahe_clip": 2.0,             # CLAHE clip limit you used
    "clahe_tile_grid": (8, 8),     # CLAHE tile grid you used
    "divide_255": True,            # False if your model already has a Rescaling layer
    "normalize_mean_std": True,    # True if you standardized with mean/std
    "mean": [0.485, 0.456, 0.406], # <-- replace with YOUR mean(s); if grayscale use single value list like [0.5]
    "std":  [0.229, 0.224, 0.225], # <-- replace with YOUR std(s); if grayscale use [0.25]
    "gamma_correction": False,     # True if you did gamma correction
    "gamma": 1.0,                  # set the gamma you used
    "unsharp": False,              # True if you sharpened
    "unsharp_amount": 1.0,         # strength
    "unsharp_sigma": 1.0,          # blur sigma
}

# ======== UTILITIES ========
import numpy as _np
from PIL import Image as _Image, ImageFilter as _ImageFilter

def _center_square_crop(img: _Image.Image) -> _Image.Image:
    w, h = img.size
    s = min(w, h)
    left = (w - s) // 2
    top = (h - s) // 2
    return img.crop((left, top, left + s, top + s))

def _to_grayscale_3c(img: _Image.Image) -> _Image.Image:
    # convert to 1-channel then back to 3 channels for models expecting RGB
    g = img.convert("L")
    return _Image.merge("RGB", (g, g, g))

def _apply_clahe_pil(img: _Image.Image, clip=2.0, tile=(8,8)) -> _Image.Image:
    # PIL doesn’t have native CLAHE; approximate via Pillow ImageOps.equalize on tiles,
    # or use OpenCV if available. We’ll prefer OpenCV if present.
    try:
        import cv2
        arr = _np.array(img)
        if arr.ndim == 3 and arr.shape[2] == 3:
            lab = cv2.cvtColor(arr, cv2.COLOR_RGB2LAB)
            l, a, b = cv2.split(lab)
            clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=tile)
            cl = clahe.apply(l)
            merged = cv2.merge((cl, a, b))
            out = cv2.cvtColor(merged, cv2.COLOR_LAB2RGB)
        else:
            clahe = cv2.createCLAHE(clipLimit=clip, tileGridSize=tile)
            out = clahe.apply(arr)
        return _Image.fromarray(out)
    except Exception:
        # Fallback: global equalization (not CLAHE), better than nothing
        from PIL import ImageOps
        return ImageOps.equalize(img)

def _apply_gamma(img: _Image.Image, gamma: float) -> _Image.Image:
    if gamma == 1.0: return img
    inv = 1.0 / max(gamma, 1e-8)
    lut = [int((i/255.0) ** inv * 255.0) for i in range(256)]
    return img.point(lut * (3 if img.mode == "RGB" else 1))

def _unsharp(img: _Image.Image, amount=1.0, sigma=1.0) -> _Image.Image:
    return img.filter(_ImageFilter.UnsharpMask(radius=sigma, percent=int(150*amount), threshold=3))

def _standardize(arr: _np.ndarray, mean, std):
    # arr: HxWxC in [0,1] (if divide_255 True) or [0,255]
    a = arr.astype("float32")
    if not PREP["divide_255"]:
        a /= 255.0
    mean = _np.array(mean, dtype="float32")
    std  = _np.array(std, dtype="float32")
    if a.ndim == 3 and a.shape[2] == 1 and mean.size == 1:
        a = (a - mean[0]) / (std[0] + 1e-8)
    else:
        # broadcast across channels
        a = (a - mean.reshape(1,1,-1)) / (std.reshape(1,1,-1) + 1e-8)
    return a

def load_keras_model():
    """
    Loads a Keras model according to MODEL_LOAD_MODE:
      - auto: prefer MODEL_PATH (h5 or SavedModel). If missing, try JSON+weights.
      - h5:   load from MODEL_PATH (single .h5 file).
      - savedmodel: load from MODEL_PATH (SavedModel dir).
      - json_weights: load from MODEL_JSON_PATH + MODEL_WEIGHTS_PATH.
    """
    global model
    if not TF_AVAILABLE:
        raise RuntimeError("TensorFlow/Keras not available. Install dependencies from requirements.txt")

    if model is not None:
        return model

    mode = MODEL_LOAD_MODE.lower()

    def _try_h5_or_savedmodel(p):
        # try .h5
        try:
            return load_model(p)
        except Exception:
            # try SavedModel directory
            return tf.keras.models.load_model(p)

    if mode == "h5":
        if not os.path.exists(MODEL_PATH):
            raise RuntimeError(f"MODEL_PATH {MODEL_PATH} not found for h5 mode.")
        model = _try_h5_or_savedmodel(MODEL_PATH)
        return model

    if mode == "savedmodel":
        if not os.path.isdir(MODEL_PATH):
            raise RuntimeError(f"MODEL_PATH {MODEL_PATH} must be a SavedModel directory for savedmodel mode.")
        model = tf.keras.models.load_model(MODEL_PATH)
        return model

    if mode == "json_weights":
        if not os.path.exists(MODEL_JSON_PATH):
            raise RuntimeError(f"MODEL_JSON_PATH {MODEL_JSON_PATH} not found.")
        if not os.path.exists(MODEL_WEIGHTS_PATH):
            raise RuntimeError(f"MODEL_WEIGHTS_PATH {MODEL_WEIGHTS_PATH} not found.")
        # If you used custom layers/activations, put them in this dict:
        custom_objects = {
            # "MyLayer": MyLayer,
            # "swish": tf.nn.swish,
        }
        with open(MODEL_JSON_PATH, "r") as f:
            j = f.read()
        model_built = model_from_json(j, custom_objects=custom_objects)
        model_built.load_weights(MODEL_WEIGHTS_PATH)
        model_built.trainable = False  # inference
        model = model_built
        return model

    # auto mode: try MODEL_PATH first, else JSON+weights
    if os.path.exists(MODEL_PATH) or os.path.isdir(MODEL_PATH):
        model = _try_h5_or_savedmodel(MODEL_PATH)
        return model

    if os.path.exists(MODEL_JSON_PATH) and os.path.exists(MODEL_WEIGHTS_PATH):
        with open(MODEL_JSON_PATH, "r") as f:
            j = f.read()
        model_built = model_from_json(j)
        model_built.load_weights(MODEL_WEIGHTS_PATH)
        model_built.trainable = False
        model = model_built
        return model

    raise RuntimeError("No model found. Provide MODEL_PATH or JSON+weights (MODEL_JSON_PATH & MODEL_WEIGHTS_PATH).")


def read_image(file_bytes: bytes) -> Image.Image:
    try:
        img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
        return img
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image file: {e}")

def preprocess(img: _Image.Image, target_size: int) -> _np.ndarray:
    # 1) (optional) grayscale pipeline
    if PREP["to_grayscale"]:
        img = _to_grayscale_3c(img)  # keep 3 channels if your model expects RGB

    # 2) (optional) crop to square BEFORE resize (common in X-ray notebooks)
    if PREP["center_square_crop"]:
        img = _center_square_crop(img)

    # 3) resize to model input
    img = img.resize((PREP["target_size"], PREP["target_size"]), resample=_Image.BILINEAR)

    # 4) (optional) CLAHE / equalization
    if PREP["use_clahe"]:
        img = _apply_clahe_pil(img, clip=PREP["clahe_clip"], tile=PREP["clahe_tile_grid"])

    # 5) (optional) gamma correction
    if PREP["gamma_correction"]:
        img = _apply_gamma(img, PREP["gamma"])

    # 6) (optional) unsharp (if you sharpened before training)
    if PREP["unsharp"]:
        img = _unsharp(img, amount=PREP["unsharp_amount"], sigma=PREP["unsharp_sigma"])

    # 7) to float array + normalize
    arr = _np.array(img).astype("float32")
    if PREP["divide_255"]:
        arr /= 255.0

    # 8) (optional) mean/std standardization (match your notebook!)
    if PREP["normalize_mean_std"]:
        # If grayscale and you used one mean/std, set mean=[x], std=[y]
        arr = _standardize(arr, PREP["mean"], PREP["std"])

    # 9) ensure correct shape for the model (N,H,W,C)
    x = _np.expand_dims(arr, axis=0)
    return x

def softmax(x: np.ndarray) -> np.ndarray:
    e = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e / np.sum(e, axis=-1, keepdims=True)

def find_last_conv_layer(m):
    # Try the provided name first
    if LAST_CONV_FALLBACK:
        try:
            return m.get_layer(LAST_CONV_FALLBACK).name
        except Exception:
            pass
    # Otherwise, search from the end
    for layer in reversed(m.layers):
        if isinstance(layer, tf.keras.layers.Conv2D):
            return layer.name
    return None

def make_gradcam_heatmap(img_array, model, last_conv_layer_name):
    # Based on Keras Grad-CAM reference implementation
    grad_model = tf.keras.models.Model(
        [model.inputs], [model.get_layer(last_conv_layer_name).output, model.output]
    )
    with tf.GradientTape() as tape:
        conv_outputs, predictions = grad_model(img_array)
        pred_index = tf.argmax(predictions[0])
        class_channel = predictions[:, pred_index]

    grads = tape.gradient(class_channel, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))
    conv_outputs = conv_outputs[0]
    heatmap = tf.reduce_sum(tf.multiply(pooled_grads, conv_outputs), axis=-1)

    heatmap = tf.maximum(heatmap, 0) / (tf.math.reduce_max(heatmap) + 1e-8)
    heatmap = heatmap.numpy()
    return heatmap

def overlay_heatmap_on_image(original: Image.Image, heatmap: np.ndarray, intensity: float = 0.35) -> Image.Image:
    heatmap_img = Image.fromarray(np.uint8(255 * heatmap)).resize(original.size)
    heatmap_img = heatmap_img.convert("RGBA")
    # Apply colormap (simple: map to red)
    r = np.array(heatmap_img)
    r[..., 0] = r[..., 0]  # red channel
    r[..., 1] = 0  # green
    r[..., 2] = 0  # blue
    r[..., 3] = (r[..., 0] * intensity).astype(np.uint8)
    heatmap_img = Image.fromarray(r, mode="RGBA")
    blended = original.convert("RGBA")
    blended = Image.alpha_composite(blended, heatmap_img)
    return blended.convert("RGB")

class PredictResponse(BaseModel):
    class_names: List[str]
    probs: List[float]
    predicted_class: str
    gradcam_image_b64: Optional[str] = None

@app.get("/health")
def health():
    return {"status": "ok", "tf": TF_AVAILABLE}

@app.post("/predict", response_model=PredictResponse)
async def predict(file: UploadFile = File(...), with_gradcam: bool = True):
    m = load_keras_model()
    content = await file.read()
    img = read_image(content)
    x = preprocess(img, DEFAULT_IMG_SIZE)
    y = m.predict(x)
    if y.ndim == 2 and y.shape[1] == len(CLASS_NAMES):
        probs = softmax(y).tolist()[0]
    else:
        # binary single-logit or single-prob
        if y.ndim == 2 and y.shape[1] == 1:
            p1 = float(1 / (1 + np.exp(-y[0, 0])))
        else:
            p1 = float(y.squeeze())
        probs = [1 - p1, p1]
        if len(CLASS_NAMES) == 2:
            pass
        else:
            # adjust class names for binary case
            CLASS_NAMES[:] = ["Negative", "Positive"]

    pred_idx = int(np.argmax(probs))
    gradcam_b64 = None

    if USE_GRADCAM and with_gradcam and TF_AVAILABLE:
        try:
            last_name = find_last_conv_layer(m)
            if last_name:
                heatmap = make_gradcam_heatmap(x, m, last_name)
                overlay = overlay_heatmap_on_image(img, heatmap)
                buf = io.BytesIO()
                overlay.save(buf, format="PNG")
                gradcam_b64 = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("utf-8")
        except Exception as e:
            # Swallow Grad-CAM errors but continue
            gradcam_b64 = None

    return PredictResponse(
        class_names=CLASS_NAMES,
        probs=[float(p) for p in probs],
        predicted_class=CLASS_NAMES[pred_idx],
        gradcam_image_b64=gradcam_b64
    )
