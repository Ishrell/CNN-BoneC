const API_URL = (window.API_URL_OVERRIDE) || "http://127.0.0.1:8000";

const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("fileInput");
const preview = document.getElementById("preview");
const previewImg = document.getElementById("previewImg");
const runBtn = document.getElementById("runBtn");
const statusEl = document.getElementById("status");
const results = document.getElementById("results");
const predicted = document.getElementById("predicted");
const probs = document.getElementById("probs");
const gradcamImg = document.getElementById("gradcamImg");
const noGradcam = document.getElementById("noGradcam");
const gradcamChk = document.getElementById("gradcamChk");

let currentFile = null;

function setStatus(msg){
  statusEl.textContent = msg || "";
}

function humanProb(p){
  return (p*100).toFixed(2) + "%";
}

function showProbs(names, vals){
  probs.innerHTML = "";
  names.forEach((name, i) => {
    const val = vals[i];
    const outer = document.createElement("div");
    const row = document.createElement("div");
    row.className = "flex justify-between text-sm";
    row.innerHTML = `<span>${name}</span><span>${humanProb(val)}</span>`;

    const barWrap = document.createElement("div");
    barWrap.className = "mt-1 w-full bg-zinc-200 dark:bg-zinc-700 rounded-full h-2 overflow-hidden";
    const bar = document.createElement("div");
    bar.className = "h-2 bg-blue-600 dark:bg-blue-500";
    bar.style.width = (val*100) + "%";
    barWrap.appendChild(bar);

    outer.appendChild(row);
    outer.appendChild(barWrap);
    probs.appendChild(outer);
  });
}

function handleFiles(files){
  if (!files || !files.length) return;
  const file = files[0];
  currentFile = file;
  const reader = new FileReader();
  reader.onload = e => {
    previewImg.src = e.target.result;
    preview.classList.remove("hidden");
    results.classList.add("hidden");
    setStatus("");
  };
  reader.readAsDataURL(file);
}

dropzone.addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", e => handleFiles(e.target.files));

["dragenter","dragover"].forEach(evt => {
  dropzone.addEventListener(evt, e => {
    e.preventDefault();
    e.stopPropagation();
    dropzone.classList.add("ring-2","ring-blue-500");
  });
});
["dragleave","drop"].forEach(evt => {
  dropzone.addEventListener(evt, e => {
    e.preventDefault();
    e.stopPropagation();
    dropzone.classList.remove("ring-2","ring-blue-500");
  });
});
dropzone.addEventListener("drop", e => {
  handleFiles(e.dataTransfer.files);
});

runBtn.addEventListener("click", async () => {
  if (!currentFile) { setStatus("Please select an image first."); return; }
  setStatus("Running scan...");
  runBtn.disabled = true;
  try {
    const form = new FormData();
    form.append("file", currentFile);
    form.append("with_gradcam", gradcamChk.checked ? "true" : "false");

    const res = await fetch(`${API_URL}/predict`, {
      method: "POST",
      body: form
    });
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`API error: ${res.status} ${t}`);
    }
    const data = await res.json();
    predicted.textContent = data.predicted_class;
    showProbs(data.class_names, data.probs);
    if (data.gradcam_image_b64) {
      gradcamImg.src = data.gradcam_image_b64;
      gradcamImg.classList.remove("hidden");
      noGradcam.classList.add("hidden");
    } else {
      gradcamImg.classList.add("hidden");
      noGradcam.classList.remove("hidden");
    }
    results.classList.remove("hidden");
    setStatus("Done.");
  } catch (err) {
    console.error(err);
    setStatus(err.message || "Something went wrong.");
  } finally {
    runBtn.disabled = false;
  }
});

// Quick health check
(async () => {
  try {
    const res = await fetch(`${API_URL}/health`);
    if (res.ok) {
      const j = await res.json();
      setStatus("API connected.");
    } else {
      setStatus("API health check failed.");
    }
  } catch(e) {
    setStatus("API not reachable. Start the backend first.");
  }
})();
